public class Search {
    private final static int VH_length = 10;
    private final static int Dia_length = 14;
    //private MinPQ<> ;
    
    
    public static void main(String argv[]){    
         
    }
}
