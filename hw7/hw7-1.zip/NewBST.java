public class NewBST<Key extends Comparable<Key>, Value> extends BST{
    public Value predecessor(Key key, int m){
    }
    public Value successor(Key key, int m){
    }    
}