public class RangeSearch {
	// please use the Point2D from algs4.jar 
	public void init(Point2D[] points){
	}
	// the result should be sorted accordingly to their x coordinates
	public Point2D[] query(Point2D ll,Point2D ur){
		Point2D[] result= new Point2D[];
		return result;
	}
}