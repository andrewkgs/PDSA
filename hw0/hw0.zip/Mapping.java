import  java.io.FileReader;

import java.io.BufferedReader;

public class Mapping {

    public static void main(String[] args) throws Exception {

        // read file from args[0] in Java 7 style
        try(BufferedReader br = new BufferedReader(new FileReader(args[0]))){

            // read a line
            String data = br.readLine();

            // store the first integer in variable readCount (number of reads)
            int readCount = Integer.parseInt(data);

            // initialization of a String array
            String[] readsArray = new String[readCount];
            String reference = new String();

            // printf in Java
            System.out.printf("%d\n",readCount);
            
            /*  now you can write your own solution to hw0
             *  you can follow the instruction described below:
             *
             *  1. read the rest content of the file
             *  2. store the reads in variable readsArray
             *  3. store the reference sequence in variable reference
             *  4. compare every reads with reference sequence
             *  5. output how many reads can be mapped to the reference sequence
             *
             *  [note]
             *  you can use every data structure in standard Java packages (Java 8 supported)
             *  the packages in stdlib.jar and algs4.jar are also available for you to use
             *
             *  [hint]
             *  1. you can use String.contain() method when comparing strings.
             *  2. you should check whether Java pass the variable by references or by values.
             *  3. some data structure such as HashSet, HashMap, Arrays, ArrayList, Vector are very
             *     useful for solving problems.
             */
        }
    }
}
